/*
 * @author Shaumik "Dada" Daityari
 * @copyright December 2013
 */

/* Some info
Using newer versions of jQuery and jQuery UI in place of the links given in problem statement
All data is stored in local storage
User data is extracted from local storage and saved in variable todo.data
Otherwise, comments are provided at appropriate places
*/

var todo = todo || {},
    data = JSON.parse(localStorage.getItem("todoData"));

data = data || {};

(function(todo, data, $) {
    console.log("hello world");
    var taskList = $(".task-list").each(function(index,elem) {
        $(elem).find("h3").click(function(){
            flag = $(this).parent().data('flag') != undefined ? 
            $(this).parent().data('flag') : true;
            flag ? $(elem).data('height',$(elem).css("height")) : ""
            origin = flag ? $(elem).css('height') :
            $(elem).data('height');

            console.log(flag, origin, $(elem).css("height"));
            $(this).parent()
            .animate({
                height: flag?$(this).css("height"): origin,
                minHeight: flag?$(this).css("height"): "240px",
            }, function() {$(elem).css({
                "overflow": flag?"hidden":"visible",
                "height": flag?$(this).css("height"):"auto"
            })})
            .data('flag',!flag);

        });
    });
    var defaults = {
            todoTask: "todo-task",
            todoHeader: "task-header",
            todoDate: "task-date",
            todoDescription: "task-description",
            taskId: "task-",
            formId: "todo-form",
            dataAttribute: "data",
            deleteDiv: "delete-div",
            taskAuthor: "task-author"
        }, codes = {
            "1" : "#pending",
            "2" : "#inProgress",
            "3" : "#completed"
        };
    todo.init = function (options) {

        options = options || {};
        options = $.extend({}, defaults, options);

        $.each(data, function (index, params) {
            generateElement(params);
        });

        /*generateElement({
            id: "123",
            code: "1",
            title: "asd",
            date: "22/12/2013",
            description: "Blah Blah"
        });*/

        /*removeElement({
            id: "123",
            code: "1",
            title: "asd",
            date: "22/12/2013",
            description: "Blah Blah"
        });*/
        //Highlight task bi het han


        // Adding drop function to each category of task
        $.each(codes, function (index, value) {
            $(value).droppable({
                drop: function (event, ui) {
                        var element = ui.helper,
                            css_id = element.attr("id"),
                            id = css_id.replace(options.taskId, ""),
                            object = data[id];

                            // Removing old element
                            removeElement(object);

                            // Changing object code
                            object.code = index;

                            // Generating new element
                            generateElement(object);

                            // Updating Local Storage
                            data[id] = object;
                            localStorage.setItem("todoData", JSON.stringify(data));

                            // Hiding Delete Area
                            $("#" + defaults.deleteDiv).hide();
                    }
            });
        });

        // Adding drop function to delete div
        $("#" + options.deleteDiv).droppable({
            drop: function(event, ui) {
                var element = ui.helper,
                    css_id = element.attr("id"),
                    id = css_id.replace(options.taskId, ""),
                    object = data[id];

                // Removing old element
                removeElement(object);

                // Updating local storage
                delete data[id];
                localStorage.setItem("todoData", JSON.stringify(data));

                // Hiding Delete Area
                $("#" + defaults.deleteDiv).hide();
            }
        })

    };

    // Add Task
    var generateElement = function(params){
        var parent = $(codes[params.code]),
            wrapper;

        if (!parent) {
            return;
        }

        wrapper = $("<div />", {
            "class" : defaults.todoTask,
            "id" : defaults.taskId + params.id,
            "data" : params.id
        }).appendTo(parent);

        // add your code here
        title = $("<div />", {
            "class" : defaults.todoHeader,
            "text": params.title
        }).appendTo(wrapper);
        description = $("<div />", {
            "class" : defaults.todoDescription,
            "text": params.description
        }).appendTo(wrapper);
        date = $("<div />", {
            "class" : defaults.todoDate,
            "text": params.date
        }).appendTo(wrapper);
        author = $("<div />", {
            "class": defaults.taskAuthor,
            "text": params.author
        }).appendTo(wrapper);

	    wrapper.draggable({
            
            // add code to implement drag and drop
            start: function() { $("#"+ defaults.deleteDiv).show()},
            drag: function () {},
            stop: function() {$("#"+ defaults.deleteDiv).hide()},
            revert: "invalid",

            revertDuration : 200
            
        
        });

        checkDate(params.id);
        generateDetails(params);




    };
    var generateDetails = function(params) {
        var html = "",
            id = "#" + defaults.taskId + params.id,
            parent = $(id);
        parent.data("height",parent.css("height"));
        parent.children(".task-header").click(function() {
            origin = parent.data("height");
            flag = parent.data('flag') != undefined ? parent.data('flag') : true;
            parent.stop(true,true)
            .animate({height: flag?$(this).css("height"): origin,
                    padding: flag? "-=5px -=0px": "+=5px -=0px"}, 'slow', 'easeInOutQuart')
            .data('flag',!flag);
        });
        parent.children().not(".task-header").click(function() {
            //create details box
            wrapper = $("<div />",{
                "class" : "detail-wrapper"
            });
            html = $("<div />",{
                "class" : "detail-box"
            }).appendTo(wrapper);
            bar = $("<div />",{
                "class" : "exit-bar"
            }).appendTo(html);

            button = $("<div />",{
                "class" : "exit-btn",
                click: () => {
                    $(wrapper).remove()
                    ;}
            }).appendTo(bar);

            btn_bar1 = $("<div />", {
                "class" : "btn-bar-left"
            }).appendTo(button); 

            btn_bar2 = $("<div />", {
                "class" : "btn-bar-right"
            }).appendTo(button);

            //insert content to box 
            contentWrapper = $("<div />", {
                "class" : "content-wrapper"
            }).appendTo(html);
            content = $("<div />", {
                "class":"content-main"
            }).appendTo(contentWrapper);
            dateCreated = [
            new Date(params.id).getDate(),
            new Date(params.id).getMonth()+1,
            new Date(params.id).getFullYear()].join("/");
            switch (true) {
                case checkDate(params.id) == "hethan":
                    status = "Overdued";
                    break;
                case params.code == "1":
                    status = "Pending";
                    break;
                case params.code == "2":
                    status = "In Progress";
                    break;
                case params.code == "3":
                    status = "Completed";
                    break;
            }
            main = $("<div class='title'>Title: " + params.title +"</div>" +
            "<div class= 'description'>Description: <em>" + params.description  +"</em></div>" +
            "<div>Due date: " + params.date +"</div>" +
            "<br>" +
            "<div class='date-created'>Date created: " + dateCreated+"</div>" +
            "<div class='status'>Status: " + status +"</div>").appendTo(content);


            //show the details box
            wrapper.appendTo($("body"));

            $("div:contains(Status: Overdued)").last().css({
                "color":"red",
                "font-weight":"bold"
            });

            $("div:contains(Status: In Progress)").last().css({
                "color":"#d80",
                "font-weight":"bold"
            });

            $("div:contains(Status: Completed)").last().css({
                "color":"#393",
                "font-weight":"bold"
            });

            $("div:contains(Status: Pending)").last().css({
                "color":"#aaa",
                "font-weight":"bold"
            });
        });


    }
    // Remove task
    var removeElement = function (params) {
        $("#" + defaults.taskId + params.id).remove();
    };

    todo.add = function() {
        var inputs = $("#" + defaults.formId + " :input"),
            titleMessage = "Title can not be empty",
            authorMessage = "Author can not be empty",
            id, title, description, date, tempData;
        if (inputs.length !== 5) {
            return;
        }

        title = inputs[0].value;
        description = inputs[1].value;
        date = inputs[2].value;
        author = inputs[3].value;

        if (!title) {
            generateDialog(titleMessage);
            return;
        }

        if (!author) {
            generateDialog(authorMessage);
            return;
        }

        id = new Date().getTime();

        tempData = {
            id : id,
            code: "1",
            title: title,
            date: date,
            description: description,
            author: author
        };

        // Saving element in local storage
        data[id] = tempData;
        //add code to save data in local storage here
        

        localStorage.setItem("todoData", JSON.stringify(data));
        // Generate Todo Element
        generateElement(tempData);
        checkDate(id);
        // Reset Form
        inputs[0].value = "";
        inputs[1].value = "";
        inputs[2].value = "";
        inputs[3].value = "";
    };

    var generateDialog = function (message) {
        var responseId = "response-dialog",
            title = "Messaage",
            responseDialog = $("#" + responseId),
            buttonOptions;
        if (!responseDialog.length) {
            responseDialog = $("<div />", {
                    title: title,
                    id: responseId
            }).appendTo($("body"));
        }

        responseDialog.html(message);

        buttonOptions = {
            "Ok" : function () {
                responseDialog.dialog("close");
            }
        };

	    responseDialog.dialog({
            autoOpen: true,
            width: 400,
            modal: true,
            closeOnEscape: true,
            buttons: buttonOptions
        });
    };

    todo.clear = function () {
        data = {};
        localStorage.setItem("todoData", JSON.stringify(data));
        $("." + defaults.todoTask).remove();
    };

    var checkDate = function(id) {
        date = data[id].date;
        date = date.split("/");
        date = [date[1], date[0], date[2]].join("/");
        now = new Date();
        now = [now.getMonth() + 1, now.getDate(), now.getFullYear()].join("/");
        if (new Date(now).getTime() - new Date(date).getTime() > 0) {
            id = '#' + defaults.taskId + id;
            $(id + " *").css("color","red");
            return "hethan";
        }
    };


})(todo, data, jQuery);

